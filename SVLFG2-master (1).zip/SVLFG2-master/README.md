# SVLFG2
2. Azubi-Jahrgang

Dies ist das gemeinsame Repository für alle Texte, Materialien, Aufgaben und Lösungen.

Für die Lösungen gibt es für die Auszubildenden jeweils ein eigenes Verzeichnis.